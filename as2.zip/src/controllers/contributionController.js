const { prisma } = require('../config/database');
const { isCurrencySupported, convert, formatAmount } = require('../services/currencyService');

const VALID_CURRENCIES = ['KZT', 'EUR', 'USD'];


async function createContribution(req, res) {
  const { giftId, amount, currency, isAnonymous } = req.body;
  const guestId = req.user.id;
  const paymentCurrency = currency || 'KZT';
  if (!VALID_CURRENCIES.includes(paymentCurrency)) {
    return res.status(400).json({
      code: 'VALIDATION_ERROR',
      message: `Invalid currency. Supported: ${VALID_CURRENCIES.join(', ')}`,
      timestamp: new Date().toISOString()
    });
  }
  
  if (!giftId || !amount || amount < 1) {
    return res.status(400).json({
      code: 'VALIDATION_ERROR',
      message: 'giftId and amount are required',
      timestamp: new Date().toISOString()
    });
  }
  
  try {
    const result = await prisma.$transaction(async (tx) => {
      const gift = await tx.gift.findUnique({
        where: { id: giftId }
      });
      
      if (!gift) {
        throw new Error('GIFT_NOT_FOUND');
      }
      
      if (gift.status === 'funded' || gift.status === 'paid_out') {
        throw new Error('GIFT_ALREADY_FUNDED');
      }
      
      const conversion = convert(amount, paymentCurrency, gift.currency);
      const amountInGiftCurrency = conversion.amount; 
      const exchangeRate = conversion.rate;           
      
      const remaining = gift.targetAmount - gift.fundedAmount;
      const maxAllowed = Math.floor(remaining * 0.8);
      
      if (amountInGiftCurrency > maxAllowed) {
        const maxInPaymentCurrency = convert(maxAllowed, gift.currency, paymentCurrency);
        throw new Error(`MAX_CONTRIBUTION_EXCEEDED:${maxInPaymentCurrency.amount}:${paymentCurrency}`);
      }
      
      if (amountInGiftCurrency < 1000 && gift.currency === 'KZT') {
        throw new Error(`MIN_AMOUNT:${formatAmount(1000, gift.currency)}`);
      }
      
      const contribution = await tx.contribution.create({
        data: {
          giftId,
          guestId,
          amount: amountInGiftCurrency,        
          exchangeRateUsed: exchangeRate,      
          currencyUsed: paymentCurrency,        
          originalAmount: amount,               
          status: 'completed',
          isAnonymous: isAnonymous || false
        }
      });
      
      
      const newFundedAmount = gift.fundedAmount + amountInGiftCurrency;
      const newStatus = newFundedAmount >= gift.targetAmount ? 'funded' : 'funding';
      
      const updatedGift = await tx.gift.update({
        where: { id: giftId },
        data: {
          fundedAmount: newFundedAmount,
          status: newStatus
        }
      });
      
      return { contribution, gift: updatedGift, conversion };
    });
    
    res.status(201).json({
      message: 'Contribution successful',
      contribution: {
        id: result.contribution.id,
        giftId: result.contribution.giftId,
        amount: result.contribution.amount,
        currency: result.gift.currency,
        paidAmount: result.contribution.originalAmount,
        paidCurrency: result.contribution.currencyUsed,
        exchangeRate: result.contribution.exchangeRateUsed,
        isAnonymous: result.contribution.isAnonymous,
        timestamp: result.contribution.timestamp
      },
      gift: {
        id: result.gift.id,
        fundedAmount: result.gift.fundedAmount,
        targetAmount: result.gift.targetAmount,
        currency: result.gift.currency,
        remainingAmount: result.gift.targetAmount - result.gift.fundedAmount,
        progressPercent: (result.gift.fundedAmount / result.gift.targetAmount) * 100,
        status: result.gift.status
      }
    });
    
  } catch (error) {
    console.error('Contribution error:', error);
    
    if (error.message === 'GIFT_NOT_FOUND') {
      return res.status(404).json({
        code: 'NOT_FOUND',
        message: 'Gift not found',
        timestamp: new Date().toISOString()
      });
    }
    
    if (error.message === 'GIFT_ALREADY_FUNDED') {
      return res.status(409).json({
        code: 'CONFLICT',
        message: 'This gift is already fully funded',
        timestamp: new Date().toISOString()
      });
    }
    
    if (error.message.startsWith('MAX_CONTRIBUTION_EXCEEDED:')) {
      const parts = error.message.split(':');
      const maxAllowed = parts[1];
      const curr = parts[2] || 'KZT';
      return res.status(400).json({
        code: 'MAX_CONTRIBUTION_EXCEEDED',
        message: `You cannot contribute more than 80% of remaining amount (max ${formatAmount(parseInt(maxAllowed), curr)})`,
        maxAllowed: parseInt(maxAllowed),
        currency: curr,
        timestamp: new Date().toISOString()
      });
    }
    
    if (error.message.startsWith('MIN_AMOUNT:')) {
      const minStr = error.message.split(':')[1];
      return res.status(400).json({
        code: 'MIN_AMOUNT',
        message: `Minimum contribution amount is ${minStr}`,
        timestamp: new Date().toISOString()
      });
    }
    
    res.status(500).json({
      code: 'INTERNAL_ERROR',
      message: error.message,
      timestamp: new Date().toISOString()
    });
  }
}

async function getContributionsByGift(req, res) {
  const { giftId } = req.params;
  
  try {
    const gift = await prisma.gift.findUnique({
      where: { id: parseInt(giftId) }
    });
    
    if (!gift) {
      return res.status(404).json({
        code: 'NOT_FOUND',
        message: 'Gift not found',
        timestamp: new Date().toISOString()
      });
    }
    
    const contributions = await prisma.contribution.findMany({
      where: { giftId: parseInt(giftId) },
      include: {
        guest: {
          select: {
            id: true,
            fullName: true
          }
        }
      },
      orderBy: { timestamp: 'desc' }
    });
    
    const totalAmount = contributions.reduce((sum, c) => sum + c.amount, 0);
    const totalOriginalAmount = contributions.reduce((sum, c) => sum + c.originalAmount, 0);
    
    res.json({
      giftId: parseInt(giftId),
      giftCurrency: gift.currency,
      totalAmount,               
      totalAmountFormatted: formatAmount(totalAmount, gift.currency),
      totalOriginalAmount,       
      totalContributors: contributions.length,
      contributions: contributions.map(c => ({
        id: c.id,
        amount: c.amount,                          
        currency: gift.currency,
        originalAmount: c.originalAmount,           
        originalCurrency: c.currencyUsed,           
        exchangeRate: c.exchangeRateUsed,           
        guestName: c.isAnonymous ? 'Anonymous' : c.guest.fullName,
        isAnonymous: c.isAnonymous,
        timestamp: c.timestamp
      }))
    });
  } catch (error) {
    console.error('Get contributions error:', error);
    res.status(500).json({
      code: 'INTERNAL_ERROR',
      message: 'Failed to get contributions',
      timestamp: new Date().toISOString()
    });
  }
}

module.exports = {
  createContribution,
  getContributionsByGift
};