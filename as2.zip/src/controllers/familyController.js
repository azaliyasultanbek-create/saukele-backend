const { prisma } = require('../config/database');
async function addFamilyMember(req, res) {
  const { guestPhone, kinshipTier } = req.body;
  const coupleId = req.user.id;
  
  if (req.user.role !== 'couple') {
    return res.status(403).json({
      code: 'FORBIDDEN',
      message: 'Only couples can add family members',
      timestamp: new Date().toISOString()
    });
  }
  
  try {
    const guest = await prisma.user.findUnique({
      where: { phone: guestPhone }
    });
    
    if (!guest) {
      return res.status(404).json({
        code: 'NOT_FOUND',
        message: 'Guest not found. User must register first.',
        timestamp: new Date().toISOString()
      });
    }
    const familyMember = await prisma.familyTree.create({
      data: {
        coupleId,
        guestId: guest.id,
        kinshipTier
      }
    });
    
    res.status(201).json({
      message: 'Family member added successfully',
      member: {
        id: familyMember.id,
        guestId: familyMember.guestId,
        guestName: guest.fullName,
        kinshipTier: familyMember.kinshipTier
      }
    });
  } catch (error) {
    console.error('Add family member error:', error);
    res.status(500).json({
      code: 'INTERNAL_ERROR',
      message: error.message,
      timestamp: new Date().toISOString()
    });
  }
}
async function getMyKinship(req, res) {
  const guestId = req.user.id;
  
  try {
    const familyEntry = await prisma.familyTree.findFirst({
      where: { guestId },
      include: {
        couple: {
          include: {
            user: true
          }
        }
      }
    });
    
    if (!familyEntry) {
      return res.json({
        kinshipTier: null,
        message: 'You are not added to any family tree yet'
      });
    }
    
    res.json({
      kinshipTier: familyEntry.kinshipTier,
      coupleName: familyEntry.couple.user.fullName,
      coupleId: familyEntry.coupleId
    });
  } catch (error) {
    console.error('Get kinship error:', error);
    res.status(500).json({
      code: 'INTERNAL_ERROR',
      message: 'Failed to get kinship info',
      timestamp: new Date().toISOString()
    });
  }
}
async function getGiftsByKinship(req, res) {
  const guestId = req.user.id;
  
  try {
    const familyEntry = await prisma.familyTree.findFirst({
      where: { guestId }
    });
    
    if (!familyEntry) {
      return res.json({
        gifts: [],
        message: 'You are not in the family tree yet'
      });
    }
    
    const userTier = familyEntry.kinshipTier;
    let allowedTiers = [];
    if (userTier === 'parents') {
      allowedTiers = ['parents', 'siblings', 'nephews', 'distant'];
    } else if (userTier === 'siblings') {
      allowedTiers = ['siblings', 'nephews', 'distant'];
    } else if (userTier === 'nephews') {
      allowedTiers = ['nephews', 'distant'];
    } else {
      allowedTiers = ['distant'];
    }
    
    const gifts = await prisma.gift.findMany({
      where: {
        coupleId: familyEntry.coupleId,
        status: { not: 'paid_out' },
        allowedTiers: {
          array_contains: allowedTiers
        }
      },
      orderBy: { createdAt: 'desc' }
    });
    
    res.json({
      guestTier: userTier,
      allowedTiers,
      gifts: gifts.map(gift => ({
        id: gift.id,
        name: gift.name,
        targetAmount: gift.targetAmount,
        fundedAmount: gift.fundedAmount,
        progressPercent: (gift.fundedAmount / gift.targetAmount) * 100,
        currency: gift.currency,
        status: gift.status
      }))
    });
  } catch (error) {
    console.error('Get gifts by kinship error:', error);
    res.status(500).json({
      code: 'INTERNAL_ERROR',
      message: 'Failed to get gifts',
      timestamp: new Date().toISOString()
    });
  }
}

module.exports = {
  addFamilyMember,
  getMyKinship,
  getGiftsByKinship
};