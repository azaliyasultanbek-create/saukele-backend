const { prisma } = require('../config/database');
const { formatAmount } = require('../services/currencyService');

const VALID_CURRENCIES = ['KZT', 'EUR', 'USD'];

async function createGift(req, res) {
  const { name, description, targetAmount, currency, allowedTiers, imageUrls } = req.body;
  const coupleId = req.user.id; 
  
  if (req.user.role !== 'couple') {
    return res.status(403).json({
      code: 'FORBIDDEN',
      message: 'Only couples can add gifts',
      timestamp: new Date().toISOString()
    });
  }
  
  const profile = await prisma.coupleProfile.findUnique({
    where: { coupleId }
  });
  
  if (!profile) {
    return res.status(404).json({
      code: 'NOT_FOUND',
      message: 'Wedding profile not found. Please create wedding profile first.',
      timestamp: new Date().toISOString()
    });
  }
  
  const giftCurrency = currency || 'KZT';
  if (!VALID_CURRENCIES.includes(giftCurrency)) {
    return res.status(400).json({
      code: 'VALIDATION_ERROR',
      message: `Invalid currency. Supported currencies: ${VALID_CURRENCIES.join(', ')}`,
      timestamp: new Date().toISOString()
    });
  }
  
  if (!name || !targetAmount || targetAmount < 1000) {
    return res.status(400).json({
      code: 'VALIDATION_ERROR',
      message: `Name is required and target amount must be at least ${formatAmount(1000, giftCurrency)}`,
      timestamp: new Date().toISOString()
    });
  }
  
  try {
    const gift = await prisma.gift.create({
      data: {
        coupleId,
        name,
        description,
        targetAmount,
        fundedAmount: 0,
        currency: giftCurrency,
        status: 'pending',
        allowedTiers: allowedTiers || ['parents', 'siblings', 'nephews', 'distant'],
        imageUrls: imageUrls || []
      }
    });
    
    res.status(201).json({
      message: 'Gift added successfully',
      gift: {
        id: gift.id,
        name: gift.name,
        description: gift.description,
        targetAmount: gift.targetAmount,
        fundedAmount: gift.fundedAmount,
        currency: gift.currency,
        status: gift.status,
        allowedTiers: gift.allowedTiers,
        createdAt: gift.createdAt
      }
    });
  } catch (error) {
    console.error('Create gift error:', error);
    res.status(500).json({
      code: 'INTERNAL_ERROR',
      message: error.message,
      timestamp: new Date().toISOString()
    });
  }
}

async function getGifts(req, res) {
  const coupleId = req.user.id;
  
  try {
    const gifts = await prisma.gift.findMany({
      where: { coupleId },
      orderBy: { createdAt: 'desc' }
    });
    
    res.json({
      gifts: gifts.map(gift => ({
        id: gift.id,
        name: gift.name,
        description: gift.description,
        targetAmount: gift.targetAmount,
        fundedAmount: gift.fundedAmount,
        remainingAmount: gift.targetAmount - gift.fundedAmount,
        progressPercent: (gift.fundedAmount / gift.targetAmount) * 100,
        currency: gift.currency,
        status: gift.status,
        allowedTiers: gift.allowedTiers,
        createdAt: gift.createdAt
      }))
    });
  } catch (error) {
    console.error('Get gifts error:', error);
    res.status(500).json({
      code: 'INTERNAL_ERROR',
      message: 'Failed to get gifts',
      timestamp: new Date().toISOString()
    });
  }
}

async function getGiftById(req, res) {
  const { giftId } = req.params;
  
  try {
    const gift = await prisma.gift.findUnique({
      where: { id: parseInt(giftId) }
    });
    
    if (!gift) {
      return res.status(404).json({
        code: 'NOT_FOUND',
        message: 'Gift not found',
        timestamp: new Date().toISOString()
      });
    }
    
    res.json({
      gift: {
        id: gift.id,
        name: gift.name,
        description: gift.description,
        targetAmount: gift.targetAmount,
        fundedAmount: gift.fundedAmount,
        remainingAmount: gift.targetAmount - gift.fundedAmount,
        progressPercent: (gift.fundedAmount / gift.targetAmount) * 100,
        currency: gift.currency,
        status: gift.status,
        allowedTiers: gift.allowedTiers,
        imageUrls: gift.imageUrls,
        createdAt: gift.createdAt
      }
    });
  } catch (error) {
    console.error('Get gift error:', error);
    res.status(500).json({
      code: 'INTERNAL_ERROR',
      message: 'Failed to get gift',
      timestamp: new Date().toISOString()
    });
  }
}

async function deleteGift(req, res) {
  const { giftId } = req.params;
  const coupleId = req.user.id;
  
  try {
    const gift = await prisma.gift.findFirst({
      where: {
        id: parseInt(giftId),
        coupleId
      }
    });
    
    if (!gift) {
      return res.status(404).json({
        code: 'NOT_FOUND',
        message: 'Gift not found or does not belong to you',
        timestamp: new Date().toISOString()
      });
    }
    
    if (gift.fundedAmount > 0) {
      return res.status(409).json({
        code: 'CONFLICT',
        message: 'Cannot delete gift with existing contributions',
        timestamp: new Date().toISOString()
      });
    }
    
    await prisma.gift.update({
      where: { id: parseInt(giftId) },
      data: { status: 'deleted' }
    });
    
    res.status(204).send();
  } catch (error) {
    console.error('Delete gift error:', error);
    res.status(500).json({
      code: 'INTERNAL_ERROR',
      message: 'Failed to delete gift',
      timestamp: new Date().toISOString()
    });
  }
}
async function updateGift(req, res) {
  const { giftId } = req.params;
  const { name, description, targetAmount, currency, allowedTiers, imageUrls } = req.body;
  const coupleId = req.user.id;
  
  if (req.user.role !== 'couple') {
    return res.status(403).json({
      code: 'FORBIDDEN',
      message: 'Only couples can update gifts',
      timestamp: new Date().toISOString()
    });
  }
  
  try {
    const gift = await prisma.gift.findFirst({
      where: {
        id: parseInt(giftId),
        coupleId
      }
    });
    
    if (!gift) {
      return res.status(404).json({
        code: 'NOT_FOUND',
        message: 'Gift not found or does not belong to you',
        timestamp: new Date().toISOString()
      });
    }
    
    if (gift.fundedAmount > 0 && (targetAmount && targetAmount !== gift.targetAmount)) {
      return res.status(409).json({
        code: 'CONFLICT',
        message: 'Cannot change gift price after contributions have been made',
        timestamp: new Date().toISOString()
      });
    }
    
    if (currency !== undefined && !VALID_CURRENCIES.includes(currency)) {
      return res.status(400).json({
        code: 'VALIDATION_ERROR',
        message: `Invalid currency. Supported: ${VALID_CURRENCIES.join(', ')}`,
        timestamp: new Date().toISOString()
      });
    }
    
    if (gift.fundedAmount > 0 && currency !== undefined && currency !== gift.currency) {
      return res.status(409).json({
        code: 'CONFLICT',
        message: 'Cannot change gift currency after contributions have been made',
        timestamp: new Date().toISOString()
      });
    }
    
    const updatedGift = await prisma.gift.update({
      where: { id: parseInt(giftId) },
      data: {
        name: name !== undefined ? name : gift.name,
        description: description !== undefined ? description : gift.description,
        targetAmount: targetAmount !== undefined ? targetAmount : gift.targetAmount,
        currency: currency !== undefined ? currency : gift.currency,
        allowedTiers: allowedTiers !== undefined ? allowedTiers : gift.allowedTiers,
        imageUrls: imageUrls !== undefined ? imageUrls : gift.imageUrls
      }
    });
    
    res.json({
      message: 'Gift updated successfully',
      gift: {
        id: updatedGift.id,
        name: updatedGift.name,
        description: updatedGift.description,
        targetAmount: updatedGift.targetAmount,
        fundedAmount: updatedGift.fundedAmount,
        currency: updatedGift.currency,
        status: updatedGift.status,
        allowedTiers: updatedGift.allowedTiers,
        imageUrls: updatedGift.imageUrls,
        createdAt: updatedGift.createdAt,
        updatedAt: updatedGift.updatedAt
      }
    });
  } catch (error) {
    console.error('Update gift error:', error);
    res.status(500).json({
      code: 'INTERNAL_ERROR',
      message: 'Failed to update gift',
      timestamp: new Date().toISOString()
    });
  }
}

module.exports = {
  createGift,
  getGifts,
  getGiftById,
  deleteGift,
  updateGift  
};