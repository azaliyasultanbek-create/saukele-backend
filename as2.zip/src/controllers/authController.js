const { body, validationResult } = require('express-validator');
const {
  registerUser,
  loginUser,
  refreshAccessToken,
  logoutUser
} = require('../services/authService');
const validateRegister = [
  body('phone')
    .matches(/^7[0-9]{10}$/)
    .withMessage('Phone must be 11 digits starting with 7 (e.g., 77071234567)'),
  body('password')
    .isLength({ min: 8 })
    .withMessage('Password must be at least 8 characters'),
  body('fullName')
    .notEmpty()
    .withMessage('Full name is required'),
  body('role')
    .optional()
    .isIn(['couple', 'guest'])
    .withMessage('Role must be couple or guest')
];
async function register(req, res) {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      code: 'VALIDATION_ERROR',
      message: 'Invalid input data',
      errors: errors.array(),
      timestamp: new Date().toISOString()
    });
  }
  
  const { phone, password, fullName, role } = req.body;
  
  try {
    const result = await registerUser(phone, password, fullName, role);
    
    res.status(201).json({
      message: 'User registered successfully',
      user: result.user,
      access_token: result.accessToken,
      refresh_token: result.refreshToken,
      token_type: 'bearer'
    });
  } catch (error) {
    if (error.message === 'USER_ALREADY_EXISTS') {
      return res.status(409).json({
        code: 'USER_EXISTS',
        message: 'User with this phone already exists',
        timestamp: new Date().toISOString()
      });
    }
    
    console.error('Registration error:', error);
    res.status(500).json({
      code: 'INTERNAL_ERROR',
      message: 'Failed to register user',
      timestamp: new Date().toISOString()
    });
  }
}
async function login(req, res) {
  const { phone, password } = req.body;
  
  if (!phone || !password) {
    return res.status(400).json({
      code: 'VALIDATION_ERROR',
      message: 'Phone and password are required',
      timestamp: new Date().toISOString()
    });
  }
  
  try {
    const result = await loginUser(phone, password);
    
    res.json({
      message: 'Login successful',
      user: result.user,
      access_token: result.accessToken,
      refresh_token: result.refreshToken,
      token_type: 'bearer'
    });
  } catch (error) {
    if (error.message === 'INVALID_CREDENTIALS') {
      return res.status(401).json({
        code: 'INVALID_CREDENTIALS',
        message: 'Invalid phone or password',
        timestamp: new Date().toISOString()
      });
    }
    
    console.error('Login error:', error);
    res.status(500).json({
      code: 'INTERNAL_ERROR',
      message: 'Failed to login',
      timestamp: new Date().toISOString()
    });
  }
}
async function refresh(req, res) {
  const { refresh_token } = req.body;
  
  if (!refresh_token) {
    return res.status(400).json({
      code: 'VALIDATION_ERROR',
      message: 'Refresh token is required',
      timestamp: new Date().toISOString()
    });
  }
  
  try {
    const decoded = require('jsonwebtoken').verify(refresh_token, require('../config/env').jwtRefreshSecret);
    const result = await refreshAccessToken(decoded.sub, refresh_token);
    
    res.json({
      access_token: result.accessToken,
      token_type: 'bearer'
    });
  } catch (error) {
    if (error.name === 'JsonWebTokenError' || error.name === 'TokenExpiredError') {
      return res.status(401).json({
        code: 'INVALID_TOKEN',
        message: 'Invalid or expired refresh token',
        timestamp: new Date().toISOString()
      });
    }
    
    if (error.message === 'INVALID_REFRESH_TOKEN') {
      return res.status(401).json({
        code: 'INVALID_TOKEN',
        message: 'Refresh token revoked or invalid',
        timestamp: new Date().toISOString()
      });
    }
    
    console.error('Refresh error:', error);
    res.status(500).json({
      code: 'INTERNAL_ERROR',
      message: 'Failed to refresh token',
      timestamp: new Date().toISOString()
    });
  }
}

async function logout(req, res) {
  const userId = req.user?.id;
  
  if (userId) {
    await logoutUser(userId);
  }
  
  res.json({
    message: 'Logout successful',
    timestamp: new Date().toISOString()
  });
}
async function me(req, res) {
  res.json({
    user: req.user,
    timestamp: new Date().toISOString()
  });
}

module.exports = {
  validateRegister,
  register,
  login,
  refresh,
  logout,
  me
};