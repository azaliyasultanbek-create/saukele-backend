const dotenv = require('dotenv');
const path = require('path');
dotenv.config({ path: path.join(__dirname, '../../.env') });
const requiredEnvVars = [
  'DATABASE_URL',
  'JWT_SECRET',
  'REDIS_URL'
];
const missingVars = requiredEnvVars.filter(varName => !process.env[varName]);

if (missingVars.length > 0) {
  console.error(' Missing required environment variables:');
  missingVars.forEach(varName => console.error(`   - ${varName}`));
  console.error('\nPlease check your .env file');
  process.exit(1);
}
if (process.env.JWT_SECRET && process.env.JWT_SECRET.length < 32) {
  console.error(' JWT_SECRET must be at least 32 characters long');
  process.exit(1);
}
console.log(' Environment variables validated');
module.exports = {
  databaseUrl: process.env.DATABASE_URL,
  jwtSecret: process.env.JWT_SECRET,
  jwtRefreshSecret: process.env.JWT_REFRESH_SECRET || process.env.JWT_SECRET,
  redisUrl: process.env.REDIS_URL,
  kaspiApiKey: process.env.KASPI_API_KEY,
  kaspiWebhookSecret: process.env.KASPI_WEBHOOK_SECRET,
  adminApiKey: process.env.ADMIN_API_KEY,
  nodeEnv: process.env.NODE_ENV || 'development',
  port: parseInt(process.env.PORT || '3000', 10),
  // Курсы валют (если нужно переопределить, например: EUR_RATE=510, USD_RATE=470)
  customRates: {
    EUR: parseFloat(process.env.EUR_RATE) || null,
    USD: parseFloat(process.env.USD_RATE) || null,
  }
};