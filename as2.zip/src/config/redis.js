const redis = require('redis');
const env = require('./env');

class MockRedisClient {
  constructor() {
    this.isOpen = true;
    console.log(' Using MOCK Redis client (for testing)');
  }
  
  async connect() {
    return this;
  }
  
  async set(key, value, options) {
    console.log(`[MOCK REDIS] SET ${key}`);
    return 'OK';
  }
  
  async get(key) {
    console.log(`[MOCK REDIS] GET ${key}`);
    return null;
  }
  
  async del(key) {
    console.log(`[MOCK REDIS] DEL ${key}`);
    return 1;
  }
  
  async expire(key, seconds) {
    console.log(`[MOCK REDIS] EXPIRE ${key}`);
    return 1;
  }
  
  async incr(key) {
    console.log(`[MOCK REDIS] INCR ${key}`);
    return 1;
  }
  
  async keys(pattern) {
    console.log(`[MOCK REDIS] KEYS ${pattern}`);
    return [];
  }
  
  on(event, callback) {
  }
}

const isTestEnv = process.env.NODE_ENV === 'test';

let redisClient;
let connectRedis;

if (isTestEnv) {
  redisClient = new MockRedisClient();
  connectRedis = async () => redisClient;
  console.log(' Test environment: using mock Redis');
} else {
  redisClient = redis.createClient({
    url: env.redisUrl
  });
  
  redisClient.on('error', (err) => {
    console.error('Redis Client Error:', err);
  });
  
  redisClient.on('connect', () => {
    console.log(' Redis connected');
  });
  
  connectRedis = async () => {
    if (!redisClient.isOpen) {
      await redisClient.connect();
    }
    return redisClient;
  };
}

module.exports = {
  redisClient,
  connectRedis
};