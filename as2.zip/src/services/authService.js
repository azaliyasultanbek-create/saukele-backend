const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const { prisma } = require('../config/database');
const { redisClient } = require('../config/redis');
const env = require('../config/env');
const SALT_ROUNDS = 10;
async function hashPassword(password) {
  return bcrypt.hash(password, SALT_ROUNDS);
}
async function verifyPassword(password, hash) {
  return bcrypt.compare(password, hash);
}
function generateAccessToken(userId, role) {
  return jwt.sign(
    { sub: userId, role, type: 'access' },
    env.jwtSecret,
    { expiresIn: '15m' }
  );
}
function generateRefreshToken(userId) {
  return jwt.sign(
    { sub: userId, type: 'refresh' },
    env.jwtRefreshSecret,
    { expiresIn: '7d' }
  );
}

async function storeRefreshToken(token, userId) {
  const key = `refresh_token:${userId}`;
  await redisClient.set(key, token, { EX: 7 * 24 * 60 * 60 }); 
}
async function verifyRefreshToken(token, userId) {
  const key = `refresh_token:${userId}`;
  const storedToken = await redisClient.get(key);
  return storedToken === token;
}
async function revokeRefreshToken(userId) {
  const key = `refresh_token:${userId}`;
  await redisClient.del(key);
}
async function registerUser(phone, password, fullName, role = 'guest') {
  const existingUser = await prisma.user.findUnique({
    where: { phone }
  });
  
  if (existingUser) {
    throw new Error('USER_ALREADY_EXISTS');
  }
  const hashedPassword = await hashPassword(password);
  const user = await prisma.user.create({
    data: {
      phone,
      passwordHash: hashedPassword,
      fullName,
      role
    }
  });
  
  const accessToken = generateAccessToken(user.id, user.role);
  const refreshToken = generateRefreshToken(user.id);
  
  await storeRefreshToken(refreshToken, user.id);
  
  return {
    user: {
      id: user.id,
      phone: user.phone,
      fullName: user.fullName,
      role: user.role
    },
    accessToken,
    refreshToken
  };
}
async function loginUser(phone, password) {
  const user = await prisma.user.findUnique({
    where: { phone }
  });
  
  if (!user) {
    throw new Error('INVALID_CREDENTIALS');
  }
  const isValid = await verifyPassword(password, user.passwordHash);
  if (!isValid) {
    throw new Error('INVALID_CREDENTIALS');
  }
  const accessToken = generateAccessToken(user.id, user.role);
  const refreshToken = generateRefreshToken(user.id);
  await storeRefreshToken(refreshToken, user.id);
  
  return {
    user: {
      id: user.id,
      phone: user.phone,
      fullName: user.fullName,
      role: user.role
    },
    accessToken,
    refreshToken
  };
}
async function refreshAccessToken(userId, refreshToken) {
  const isValid = await verifyRefreshToken(refreshToken, userId);
  if (!isValid) {
    throw new Error('INVALID_REFRESH_TOKEN');
  }
  
  const user = await prisma.user.findUnique({
    where: { id: userId }
  });
  
  if (!user) {
    throw new Error('USER_NOT_FOUND');
  }
  const newAccessToken = generateAccessToken(user.id, user.role);
  
  return { accessToken: newAccessToken };
}
async function logoutUser(userId) {
  await revokeRefreshToken(userId);
}
async function getUserById(userId) {
  const user = await prisma.user.findUnique({
    where: { id: userId },
    select: {
      id: true,
      phone: true,
      fullName: true,
      role: true,
      createdAt: true
    }
  });
  
  return user;
}

module.exports = {
  registerUser,
  loginUser,
  refreshAccessToken,
  logoutUser,
  getUserById,
  generateAccessToken,
  verifyRefreshToken
};