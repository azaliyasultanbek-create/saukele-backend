const express = require('express');
const { authenticate } = require('../middleware/auth');
const {
  createContribution,
  getContributionsByGift
} = require('../controllers/contributionController');
const router = express.Router();
router.post('/', authenticate, createContribution);
router.get('/gift/:giftId', authenticate, getContributionsByGift);

module.exports = router;