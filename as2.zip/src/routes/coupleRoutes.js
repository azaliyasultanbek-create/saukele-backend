const express = require('express');
const { authenticate, requireRole } = require('../middleware/auth');
const {
  createWeddingProfile,
  getWeddingProfile,
  getAllWeddings,
  updateWeddingProfile  
} = require('../controllers/coupleController');

const router = express.Router();

router.post('/profile', authenticate, requireRole('couple'), createWeddingProfile);
router.put('/profile/:coupleId', authenticate, requireRole('couple'), updateWeddingProfile);
router.get('/profile/:coupleId', authenticate, getWeddingProfile);
router.get('/', getAllWeddings);

module.exports = router;