const express = require('express');
const { authenticate, requireRole } = require('../middleware/auth');
const {
  addFamilyMember,
  getMyKinship,
  getGiftsByKinship
} = require('../controllers/familyController');

const router = express.Router();
router.post('/members', authenticate, requireRole('couple'), addFamilyMember);
router.get('/my-kinship', authenticate, getMyKinship);
router.get('/gifts', authenticate, getGiftsByKinship);

module.exports = router;