const express = require('express');
const { authenticate } = require('../middleware/auth');
const {
  validateRegister,
  register,
  login,
  refresh,
  logout,
  me
} = require('../controllers/authController');
const router = express.Router(); 
router.post('/register', validateRegister, register);
router.post('/login', login);
router.post('/refresh', refresh);
router.post('/logout', authenticate, logout);
router.get('/me', authenticate, me);
router.get('/redis-check', async (req, res) => {
  try {
    const { redisClient } = require('../config/redis');
    const keys = await redisClient.keys('*');
    res.json({ keys, redisWorking: true });
  } catch (error) {
    res.json({ redisWorking: false, error: error.message });
  }
});

module.exports = router;