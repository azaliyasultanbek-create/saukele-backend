const express = require('express');
const { authenticate, requireRole } = require('../middleware/auth');
const {
  createGift,
  getGifts,
  getGiftById,
  deleteGift,
  updateGift  
} = require('../controllers/giftController');

const router = express.Router();
router.use(authenticate);
router.use(requireRole('couple'));

router.post('/', createGift);
router.get('/', getGifts);
router.get('/:giftId', getGiftById);
router.put('/:giftId', updateGift);  
router.delete('/:giftId', deleteGift);

module.exports = router;