const app = require('./app');
const env = require('./config/env');
const { prisma } = require('./config/database');
const { connectRedis } = require('./config/redis');
async function startServer() {
  try {
    await prisma.$connect();
    console.log(' Database connected');
    await connectRedis();
    const server = app.listen(env.port, () => {
      console.log(` Server running on port ${env.port}`);
      console.log(` Environment: ${env.nodeEnv}`);
    });
    const shutdown = async () => {
      console.log('Shutting down gracefully...');
      server.close(async () => {
        await prisma.$disconnect();
        console.log(' Cleanup completed');
        process.exit(0);
      });
    };
    
    process.on('SIGTERM', shutdown);
    process.on('SIGINT', shutdown);
    
  } catch (error) {
    console.error(' Failed to start server:', error.message);
    process.exit(1);
  }
}

startServer();