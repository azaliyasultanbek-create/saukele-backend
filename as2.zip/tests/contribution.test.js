const request = require('supertest');
const app = require('../src/app');

describe('Contributions API Tests', () => {
  let coupleToken, guestToken, giftId;
  const couplePhone = `7707${Date.now()}1`.slice(0, 11);
  const guestPhone = `7707${Date.now()}2`.slice(0, 11);
  
  beforeAll(async () => {
    await request(app).post('/auth/register').send({
      phone: couplePhone,
      password: 'Couple123',
      fullName: 'Test Couple',
      role: 'couple'
    });
    
    const coupleLogin = await request(app).post('/auth/login').send({
      phone: couplePhone,
      password: 'Couple123'
    });
    coupleToken = coupleLogin.body.access_token;
    await request(app).post('/auth/register').send({
      phone: guestPhone,
      password: 'Guest123',
      fullName: 'Test Guest',
      role: 'guest'
    });
    
    const guestLogin = await request(app).post('/auth/login').send({
      phone: guestPhone,
      password: 'Guest123'
    });
    guestToken = guestLogin.body.access_token;
    const gift = await request(app)
      .post('/gifts')
      .set('Authorization', `Bearer ${coupleToken}`)
      .send({
        name: 'Test Gift',
        targetAmount: 100000,
        currency: 'KZT'
      });
    
    giftId = gift.body.gift?.id;
  });
  
  test('POST /contributions - guest can contribute to gift', async () => {
    if (!giftId) {
      console.log('Skipping test - gift not created');
      return;
    }
    
    const res = await request(app)
      .post('/contributions')
      .set('Authorization', `Bearer ${guestToken}`)
      .send({
        giftId,
        amount: 10000
      });
    
    expect(res.statusCode).toBe(201);
    expect(res.body.contribution.amount).toBe(10000);
  });
  
  test('GET /health - server works', async () => {
    const res = await request(app).get('/health');
    expect(res.statusCode).toBe(200);
  });
});