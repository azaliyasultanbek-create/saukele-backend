const request = require('supertest');
const app = require('../src/app');

describe('Auth API Tests', () => {
  const uniquePhone = `7707${Date.now()}`.slice(0, 11);

  const testUser = {
    phone: uniquePhone,
    password: 'Test123456',
    fullName: 'Test Student',
    role: 'guest'
  };

  test('POST /auth/register - should create new user', async () => {
    const res = await request(app)
      .post('/auth/register')
      .send(testUser);

    expect(res.statusCode).toBe(201);
    expect(res.body).toHaveProperty('access_token');
  });

  test('POST /auth/login - should login successfully', async () => {
    const res = await request(app)
      .post('/auth/login')
      .send({
        phone: testUser.phone,
        password: testUser.password
      });

    expect(res.statusCode).toBe(200);
    expect(res.body).toHaveProperty('access_token');
  });

  test('POST /auth/login - should fail with wrong password', async () => {
    const res = await request(app)
      .post('/auth/login')
      .send({
        phone: testUser.phone,
        password: 'wrongpassword'
      });

    expect(res.statusCode).toBe(401);
  });
  test('GET /gifts - should fail without token', async () => {
    const res = await request(app).get('/gifts');
    expect(res.statusCode).toBe(401);
  });

  test('POST /gifts - guest should get 403', async () => {
    const login = await request(app).post('/auth/login').send({
      phone: testUser.phone,
      password: testUser.password
    });

    const token = login.body.access_token;

    const res = await request(app)
      .post('/gifts')
      .set('Authorization', `Bearer ${token}`)
      .send({
        name: 'Forbidden Gift',
        targetAmount: 10000
      });

    expect(res.statusCode).toBe(403);
  });

  test('GET /health - server should respond', async () => {
    const res = await request(app).get('/health');
    expect(res.statusCode).toBe(200);
    expect(res.body.status).toBe('ok');
  });
});